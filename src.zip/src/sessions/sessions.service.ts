import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { nanoid } from 'nanoid';
import { CreateSessionDto, SaveProgressDto } from './dto';

type SavedItem = {
  questionId: string;
  chosenOptionIds: string[];
  answeredAt: string; // ISO
  flagged?: boolean;
};

function normalizeDiff(d?: string) {
  if (!d) return undefined;
  const v = d.toLowerCase();
  return (['easy', 'medium', 'hard'].includes(v) ? (v as 'easy' | 'medium' | 'hard') : undefined);
}

@Injectable()
export class SessionsService {
  constructor(private prisma: PrismaService) {}

  async get(id: string) {
    const session = await this.prisma.quizSession.findUnique({ where: { attemptId: id } });
    if (!session) throw new NotFoundException('Session not found');

    const questionIds: string[] = (session.questionIds as any) ?? [];

    const questions = await this.prisma.question.findMany({
      where: { id: { in: questionIds } },
      include: { options: { orderBy: { id: 'asc' } }, category: true },
      orderBy: { createdAt: 'asc' },
    });

    // restore order saved at create-time
    const indexOf = new Map<string, number>(questionIds.map((qid, i) => [qid, i]));
    questions.sort((a, b) => (indexOf.get(a.id)! - indexOf.get(b.id)!));

    const cat = await this.prisma.category.findUnique({ where: { id: session.categoryId } });

    const dtoQuestions = questions.map((q) => ({
      id: q.id,
      text: q.text,
      type: q.type as any,
      imageUrl: q.imageUrl ?? undefined,
      options: q.options.map((o) => ({ id: o.id, text: o.text })), // no shuffle
      explanation: undefined,
      difficulty: q.difficulty as any,
    }));

    const persistedEnd =
      session.endAt ?? new Date(session.startAt.getTime() + (session.timeLimitSec ?? 600) * 1000);

    return {
      id: session.attemptId,
      categoryId: session.categoryId,
      category: cat && {
        id: cat.id,
        name: cat.name,
        slug: cat.slug,
        description: cat.description ?? undefined,
        color: cat.color ?? undefined,
        icon: cat.icon ?? undefined,
      },
      numQuestions: session.numQuestions,
      difficulty: (session.difficulty ?? undefined) as any,
      timeLimitSec: session.timeLimitSec ?? 600,
      startAt: session.startAt.toISOString(),
      endAt: persistedEnd.toISOString(),
      serverNow: new Date().toISOString(),
      questions: dtoQuestions,
      currentAnswers: Object.fromEntries(
        (((session.savedAnswers as any) ?? []) as SavedItem[]).map((a) => [a.questionId, a.chosenOptionIds]),
      ),
      isCompleted: session.isCompleted,
      submittedAt: undefined,
      score: session.score ?? undefined,
    };
  }

  async create(body: CreateSessionDto) {
    const { categoryId, numQuestions, difficulty, timeLimitMin, timeLimitMinutes } = body;
    const targetDiff = normalizeDiff(difficulty);
    const timeLimitSec = (timeLimitMin ?? timeLimitMinutes ?? 10) * 60;

    // deterministic selection; frontend will handle shuffling
    const usable = await this.prisma.question.findMany({
      where: { categoryId, ...(targetDiff ? { difficulty: targetDiff as any } : {}) },
      include: { options: { orderBy: { id: 'asc' } } },
      orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
      take: Math.max(0, numQuestions),
    });

    const fallback = !usable.length
      ? await this.prisma.question.findMany({
          where: { categoryId },
          include: { options: { orderBy: { id: 'asc' } } },
          orderBy: [{ createdAt: 'asc' }, { id: 'asc' }],
          take: Math.max(0, numQuestions),
        })
      : usable;

    const selected = fallback;

    const attemptId = nanoid(10);
    const startAt = new Date();
    const endAt = new Date(startAt.getTime() + timeLimitSec * 1000);

    await this.prisma.quizSession.create({
      data: {
        attemptId,
        categoryId,
        questionIds: selected.map((q) => q.id),
        numQuestions: selected.length,
        difficulty: targetDiff as any,
        timeLimitSec,
        startAt,
        endAt,
      } as any,
    });

    const cat = await this.prisma.category.findUnique({ where: { id: categoryId } });

    const questions = selected.map((q) => ({
      id: q.id,
      text: q.text,
      type: q.type as any,
      imageUrl: q.imageUrl ?? undefined,
      options: q.options.map((o) => ({ id: o.id, text: o.text })),
      explanation: undefined,
      difficulty: q.difficulty as any,
    }));

    return {
      attemptId,
      startAt: startAt.toISOString(),
      endAt: endAt.toISOString(),
      timeLimitSec,
      serverNow: new Date().toISOString(),
      questions,
      category: cat && {
        id: cat.id,
        name: cat.name,
        slug: cat.slug,
        description: cat.description ?? undefined,
        color: cat.color ?? undefined,
        icon: cat.icon ?? undefined,
      },
    };
  }

  async saveProgress(id: string, body: SaveProgressDto) {
    const session = await this.prisma.quizSession.findUnique({ where: { attemptId: id } });
    if (!session) throw new NotFoundException('Session not found');
    const nowISO = new Date().toISOString();
    const saved: SavedItem[] = (body.answers ?? []).map((a) => ({
      questionId: a.questionId,
      chosenOptionIds: a.chosenOptionIds ?? [],
      answeredAt: nowISO,
    }));
    await this.prisma.quizSession.update({
      where: { id: session.id },
      data: { savedAnswers: saved as any },
    });
    return { saved: true, serverNow: new Date().toISOString() };
  }

  async submit(id: string, body?: SaveProgressDto) {
    const session = await this.prisma.quizSession.findUnique({ where: { attemptId: id } });
    if (!session) throw new NotFoundException('Session not found');

    // Use answers from body if provided; otherwise use saved progress
    let answers: SavedItem[] = ((session.savedAnswers as any) ?? []) as SavedItem[];
    if (body?.answers && body.answers.length) {
      const nowISO = new Date().toISOString();
      answers = body.answers.map((a) => ({
        questionId: a.questionId,
        chosenOptionIds: a.chosenOptionIds ?? [],
        answeredAt: nowISO,
      }));
      await this.prisma.quizSession.update({
        where: { id: session.id },
        data: { savedAnswers: answers as any },
      });
    }

    const byQ = new Map(answers.map((a) => [a.questionId, a.chosenOptionIds]));
    const questionIds: string[] = (session.questionIds as any) ?? [];
    const qs = await this.prisma.question.findMany({
      where: { id: { in: questionIds } },
      include: { options: true },
    });

    let correctCount = 0;
    let incorrectCount = 0;
    let unselectedCount = 0;
    const breakdown: any[] = [];

    for (const q of qs) {
      const userAnswerIds = byQ.get(q.id) ?? [];
      const correctAnswerIds = q.options.filter((o) => o.isCorrect).map((o) => o.id);
      const isCorrect =
        userAnswerIds.length === correctAnswerIds.length &&
        userAnswerIds.every((oid) => correctAnswerIds.includes(oid));

      if (userAnswerIds.length === 0) unselectedCount++;
      else if (isCorrect) correctCount++;
      else incorrectCount++;

      breakdown.push({
        questionId: q.id,
        isCorrect,
        userAnswerIds,
        correctAnswerIds,
        userAnswerTexts: q.options.filter((o) => userAnswerIds.includes(o.id)).map((o) => o.text),
        correctAnswerTexts: q.options.filter((o) => correctAnswerIds.includes(o.id)).map((o) => o.text),
        explanation: q.explanation ?? null,
      });
    }

    const total = questionIds.length;
    const timeTakenSec = Math.max(
      0,
      Math.floor((Date.now() - new Date(session.startAt).getTime()) / 1000),
    );
    const score = total > 0 ? Math.round((correctCount / total) * 100) : 0;
    const submittedAt = new Date();

    await this.prisma.quizSession.update({
      where: { id: session.id },
      data: { isCompleted: true, score, timeTakenSec, endAt: submittedAt },
    });

    return {
      attemptId: id,
      score,
      correctCount,
      incorrectCount,
      unselectedCount,
      total,
      timeTakenSec,
      submittedAt: submittedAt.toISOString(),
      rank: 50,
      percentile: 0,
      breakdown,
    };
  }
}
