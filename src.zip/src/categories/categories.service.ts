import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCategoryDto, UpdateCategoryDto } from './dto';

@Injectable()
export class CategoriesService {
  constructor(private prisma: PrismaService) {}

  async list() {
    const cats = await this.prisma.category.findMany({
      orderBy: [{ sortOrder: 'asc' as any }, { createdAt: 'asc' }],
    });
    if (!cats.length) return [];

    const ids = cats.map((c) => c.id);
    const entries = await Promise.all(
      ids.map(async (id) => [id, await this.prisma.question.count({ where: { categoryId: id } })] as const),
    );
    const countMap = new Map<string, number>(entries.map(([id, cnt]) => [id, cnt]));

    return cats.map((c) => ({ ...c, questionCount: countMap.get(c.id) ?? 0 }));
  }

  async get(id: string) {
    const cat = await this.prisma.category.findUnique({ where: { id } });
    if (!cat) throw new NotFoundException('Category not found');
    const questionCount = await this.prisma.question.count({ where: { categoryId: id } });
    return { ...cat, questionCount };
  }

  async create(body: CreateCategoryDto) {
    const exists = await this.prisma.category.findUnique({ where: { slug: body.slug } });
    if (exists) throw new ConflictException('Slug already exists');
    return this.prisma.category.create({ data: body as any });
  }

  async update(id: string, body: UpdateCategoryDto) {
    try {
      return await this.prisma.category.update({ where: { id }, data: body as any });
    } catch {
      throw new NotFoundException('Category not found');
    }
  }

  async remove(id: string) {
    const cat = await this.prisma.category.findUnique({ where: { id } });
    if (!cat) throw new NotFoundException('Category not found');
    if (cat.isDefault) throw new ConflictException('Cannot delete default category');
    const qCount = await this.prisma.question.count({ where: { categoryId: id } });
    if (qCount > 0) throw new ConflictException('Cannot delete category with questions');
    await this.prisma.category.delete({ where: { id } });
    return { ok: true };
  }
}
